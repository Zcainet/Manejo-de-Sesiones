
# Roles y Sesiones - Guía Rápida

## Backend
- CORS con credenciales: origin `http://localhost:3000`
- Middlewares:
  - `requireLogin` → exige sesión.
  - `requireRole('admin')` → exige rol admin.
- Endpoints protegidos:
  - `/usuarios` (GET/POST/PUT/DELETE) → admin
  - `/videojuegos` (POST/PUT/DELETE) → admin
- Público:
  - `/videojuegos` (GET) → abierto
  - `/login` (POST) → inicia sesión
  - `/me` (GET) → devuelve usuario en sesión

## Frontend
- `login.html` guarda `data.usuario` en `localStorage`.
- Se usa `credentials: 'include'` en fetch para enviar la cookie de sesión.
- Páginas con guard de rol:
  - `alta_menu.html`, `alta_usuario.html`, `usuarios.html` → solo admin
  - `videojuegos.html` → oculta acciones si no admin

## Sugerencias
- Cambiar `origin` de CORS a tu dominio/puerto de producción.
- Usar `secure: true` en cookie cuando sirvas por HTTPS.
- Mover credenciales a variables de entorno (.env).
