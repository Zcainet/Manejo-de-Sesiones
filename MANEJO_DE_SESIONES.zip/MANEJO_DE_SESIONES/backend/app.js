const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const bcrypt = require('bcryptjs');
const path = require('path');

// Dependencias para sesiones seguras
const cors = require('cors');
const session = require('express-session');


const app = express();
const PORT = 3000;

// --- DB ---
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'crud_juegos'
});

db.connect((err) => {
  if (err) throw err;
  console.log('✅ Conectado a MySQL');
});

app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));

// --- middlewares base ---
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../frontend')));

app.use(session({
  secret: 'clave_super_segura',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: false 
  }
}));

/** Middlewares de autenticación y autorización **/
function requireLogin(req, res, next) {
  if (!req.session || !req.session.usuario) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  next();
}

function requireRole(rolEsperado) {
  return (req, res, next) => {
    if (!req.session?.usuario || req.session.usuario.rol !== rolEsperado) {
      return res.status(403).json({ error: 'No autorizado' });
    }
    next();
  };
}


app.get('/me', (req, res) => {
  if (req.session?.usuario) return res.json(req.session.usuario);
  res.status(401).json({ error: 'No autenticado' });
});

app.get('/', (req, res) => {
  res.redirect('/login.html');
});

// LOGIN con guardado en sesión
app.post('/login', (req, res) => {
  const { correo, contrasena } = req.body;

  db.query('SELECT * FROM usuarios WHERE correo = ?', [correo], async (err, results) => {
    if (err) return res.status(500).json({ error: 'Error de servidor' });
    if (results.length === 0) return res.status(401).json({ error: 'Correo no registrado' });

    const usuario = results[0];
    const match = await bcrypt.compare(contrasena, usuario.contrasena);
    if (!match) return res.status(401).json({ error: 'Contraseña incorrecta' });

    // Guardar datos en la sesión
    req.session.usuario = { id: usuario.id, nombre: usuario.nombre, correo: usuario.correo, rol: usuario.rol };

    res.json({ mensaje: 'Sesión iniciada', usuario: req.session.usuario });
  });
});

// Ruta protegida para dashboard
app.get('/dashboard', (req, res) => {
  if (req.session.usuario) {
    return res.json({ mensaje: 'Bienvenido', usuario: req.session.usuario });
  }
  res.status(401).json({ mensaje: 'No autorizado' });
});

// Cerrar sesión
app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('connect.sid');
    res.json({ mensaje: 'Sesión cerrada' });
  });
});

// CRUD USUARIOS (solo admin)
app.get('/usuarios', requireLogin, requireRole('admin'), (req, res) => {
  db.query('SELECT * FROM usuarios', (err, results) => {
    if (err) return res.status(500).send('Error al obtener usuarios');
    res.json(results);
  });
});

app.post('/usuarios', requireLogin, requireRole('admin'), async (req, res) => {
  const { nombre, correo, contrasena, rol } = req.body;
  if (!nombre || !correo || !contrasena) return res.status(400).send('Datos incompletos');

  const hash = await bcrypt.hash(contrasena, 10);
  const rolUsuario = rol ? rol.trim() : 'usuario';

  db.query(
    'INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES (?, ?, ?, ?)',
    [nombre.trim(), correo.trim(), hash, rolUsuario],
    (err) => {
      if (err) return res.status(500).send('Error al agregar usuario');
      res.send('Usuario agregado con éxito');
    }
  );
});

app.put('/usuarios/:id', requireLogin, requireRole('admin'), async (req, res) => {
  const { nombre, correo, contrasena, rol } = req.body;
  const id = req.params.id;

  let query = 'UPDATE usuarios SET nombre=?, correo=?';
  const values = [nombre.trim(), correo.trim()];

  if (contrasena) {
    const hash = await bcrypt.hash(contrasena, 10);
    query += ', contrasena=?';
    values.push(hash);
  }

  if (rol) {
    query += ', rol=?';
    values.push(rol.trim());
  }

  query += ' WHERE id=?';
  values.push(id);

  db.query(query, values, (err) => {
    if (err) return res.status(500).send('Error al actualizar usuario');
    res.send('Usuario actualizado');
  });
});

app.delete('/usuarios/:id', requireLogin, requireRole('admin'), (req, res) => {
  db.query('DELETE FROM usuarios WHERE id=?', [req.params.id], (err) => {
    if (err) return res.status(500).send('Error al eliminar usuario');
    res.send('Usuario eliminado');
  });
});

// CRUD VIDEOJUEGOS
app.get('/videojuegos', (req, res) => {
  db.query('SELECT * FROM videojuegos', (err, results) => {
    if (err) return res.status(500).send('Error al obtener videojuegos');
    res.json(results);
  });
});

app.post('/videojuegos', requireLogin, requireRole('admin'), (req, res) => {
  const { titulo, genero, plataforma, usuario_id } = req.body;
  if (!titulo || !genero || !plataforma || !usuario_id)
    return res.status(400).send('Datos incompletos');

  db.query(
    'INSERT INTO videojuegos (titulo, genero, plataforma, usuario_id) VALUES (?, ?, ?, ?)',
    [titulo.trim(), genero.trim(), plataforma.trim(), usuario_id],
    (err) => {
      if (err) return res.status(500).send('Error al agregar videojuego');
      res.send('Videojuego agregado con éxito');
    }
  );
});

app.put('/videojuegos/:id', requireLogin, requireRole('admin'), (req, res) => {
  const { titulo, genero, plataforma, usuario_id } = req.body;

  db.query(
    'UPDATE videojuegos SET titulo=?, genero=?, plataforma=?, usuario_id=? WHERE id=?',
    [titulo.trim(), genero.trim(), plataforma.trim(), usuario_id, req.params.id],
    (err) => {
      if (err) return res.status(500).send('Error al actualizar videojuego');
      res.send('Videojuego actualizado');
    }
  );
});

app.delete('/videojuegos/:id', requireLogin, requireRole('admin'), (req, res) => {
  db.query('DELETE FROM videojuegos WHERE id=?', [req.params.id], (err) => {
    if (err) return res.status(500).send('Error al eliminar videojuego');
    res.send('Videojuego eliminado');
  });
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
