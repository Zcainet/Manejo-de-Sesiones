const bcrypt = require('bcrypt');
const mysql = require('mysql2/promise');

async function createUser() {
  try {
    const connection = await mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password: '',
      database: 'crud_juegos'
    });

    const nombre = 'Jose L'
    const correo = 'jose@crud.com';
    const password = 'MMO';
    const rol = 'admin';
    //MMO
    //toro
    const hashedPassword = await bcrypt.hash(password, 10);

    await connection.execute(
      'INSERT INTO usuarios (nombre, correo, contrasena, rol) VALUES (?, ?, ?, ?)',
      [nombre, correo, hashedPassword, rol]
    );

    console.log(`✅ Usuario "${nombre}" con rol "${rol}" creado con contraseña hasheada.`);
    await connection.end();
  } catch (err) {
    console.error('❌ Error al crear el usuario:', err.message);
  }
}

createUser();
