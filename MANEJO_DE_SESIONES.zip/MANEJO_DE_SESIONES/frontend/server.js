const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

let usuarios = [
  { id: 1, nombre: 'Juan Pérez', correo: 'juan@example.com', contrasena: '123456' },
  { id: 2, nombre: 'Ana García', correo: 'ana@example.com', contrasena: '654321' }
];

let videojuegos = [
  { id: 1, titulo: 'Zelda', genero: 'Aventura', plataforma: 'Switch', usuario_id: 1 }
];

// ------- RUTAS USUARIOS -------
app.get('/api/usuarios', (req, res) => res.json(usuarios));

app.post('/api/usuarios', (req, res) => {
  const nuevo = { ...req.body, id: Date.now() };
  usuarios.push(nuevo);
  res.status(201).json(nuevo);
});

app.put('/api/usuarios/:id', (req, res) => {
  const id = parseInt(req.params.id);
  usuarios = usuarios.map(u => u.id === id ? { ...u, ...req.body } : u);
  res.json({ mensaje: 'Usuario actualizado' });
});

app.delete('/api/usuarios/:id', (req, res) => {
  const id = parseInt(req.params.id);
  usuarios = usuarios.filter(u => u.id !== id);
  res.json({ mensaje: 'Usuario eliminado' });
});

// ------- RUTAS VIDEOJUEGOS -------
app.get('/api/videojuegos', (req, res) => res.json(videojuegos));

app.post('/api/videojuegos', (req, res) => {
  const nuevo = { ...req.body, id: Date.now() };
  videojuegos.push(nuevo);
  res.status(201).json(nuevo);
});

app.put('/api/videojuegos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  videojuegos = videojuegos.map(v => v.id === id ? { ...v, ...req.body } : v);
  res.json({ mensaje: 'Videojuego actualizado' });
});

app.delete('/api/videojuegos/:id', (req, res) => {
  const id = parseInt(req.params.id);
  videojuegos = videojuegos.filter(v => v.id !== id);
  res.json({ mensaje: 'Videojuego eliminado' });
});

// ------- RUTA DE LOGIN -------
app.post('/api/login', (req, res) => {
  const { correo, contrasena } = req.body;
  const usuario = usuarios.find(u => u.correo === correo && u.contrasena === contrasena);

  if (usuario) {
    res.json({ usuario: { id: usuario.id, nombre: usuario.nombre, correo: usuario.correo } });
  } else {
    res.status(401).json({ mensaje: 'Credenciales inválidas' });
  }
});

app.listen(PORT, () => console.log(`Servidor en http://localhost:${PORT}`));
