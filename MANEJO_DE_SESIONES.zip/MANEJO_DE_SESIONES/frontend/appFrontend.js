const apiUsuarios = 'http://localhost:3000/usuarios';
const apiVideojuegos = 'http://localhost:3000/videojuegos';


// USUARIOS
if (document.getElementById('usuarioForm')) {
  const form = document.getElementById('usuarioForm');
  const tabla = document.getElementById('usuariosTabla').getElementsByTagName('tbody')[0];
  const idInput = document.getElementById('usuarioId');

  const obtenerUsuarios = async () => {
    const res = await fetch(apiUsuarios, { credentials: 'include' });
    const data = await res.json();
    tabla.innerHTML = '';
    data.forEach(usuario => {
      tabla.innerHTML += `
        <tr>
          <td>${usuario.id}</td>
          <td>${usuario.nombre}</td>
          <td>${usuario.correo}</td>
          <td>${usuario.rol || ''}</td>
          <td>
            <button onclick="editarUsuario(${usuario.id}, '${usuario.nombre}', '${usuario.correo}', '${usuario.rol || ''}')" class="btn btn-warning btn-sm">Editar</button>
            <button onclick="eliminarUsuario(${usuario.id})" class="btn btn-danger btn-sm">Eliminar</button>
          </td>
        </tr>
      `;
    });
  };

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const usuario = {
      nombre: document.getElementById('nombre').value,
      correo: document.getElementById('correo').value,
      contrasena: document.getElementById('contrasena').value,
      rol: document.getElementById('rol').value
    };
    const metodo = idInput.value ? 'PUT' : 'POST';
    const url = idInput.value ? `${apiUsuarios}/${idInput.value}` : apiUsuarios;
    await fetch(url, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(usuario)
    });
    form.reset();
    idInput.value = '';
    obtenerUsuarios();
  });

  window.editarUsuario = (id, nombre, correo, rol) => {
    document.getElementById('usuarioId').value = id;
    document.getElementById('nombre').value = nombre;
    document.getElementById('correo').value = correo;
    document.getElementById('rol').value = rol;
  };

  window.eliminarUsuario = async id => {
    if (confirm('¿Eliminar este usuario?')) {
      await fetch(`${apiUsuarios}/${id}`, { credentials: 'include',  method: 'DELETE' });
      obtenerUsuarios();
    }
  };

  obtenerUsuarios();
}


